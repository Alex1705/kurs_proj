function view_validation_message(success){
    if (success){
        mess_box.className = "success_message";
        var img_src = "../static/images/ok.svg";
        var img = "<img src=\""+img_src+"\">";
        mess_box.innerHTML = img;
        return true;
    }
    else{
        mess_box.className = "fail_message";
        var img_src = "../static/images/error.svg";
        var img = "<img src=\""+img_src+"\">";
        var txt = "Некорректное значение";
        mess_box.innerHTML = img+txt;
        return false;
    }
}
function is_e_mail_valid(){
    mess_box = document.getElementById('mess_for_email');
    var e_mail=document.getElementById("id_email").value;
    return view_validation_message( /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/.test(e_mail))
}
function log_pass_valid(value){
    if(/^.{0,}[\@\#\$\%\^\&\*\:\; \\\/\,\.\'\"\+\=].{0,}$/.test(value))
    {
        return false;
    }
    else return true;
}
function login_valid(){
    mess_box = document.getElementById('mess_for_username');
    value=document.getElementById("id_username").value;
    return view_validation_message(log_pass_valid(value)&&value.length>=3)
}
function password_valid(){
    mess_box = document.getElementById('mess_for_pass');
    value=document.getElementById("id_password").value;
    return view_validation_message(log_pass_valid(value)&&value.length>=8)
}
function password_confirm() {
    mess_box = document.getElementById('mess_for_conf_pass');
    value=document.getElementById("id_password").value;
    return view_validation_message(value==document.getElementById("id_confirm_pass").value&&value.length>=8)

}
function sign_up_confirm(){
    one= password_valid();
    two= is_e_mail_valid();
    if(login_valid()&&one&&password_confirm()&&two){
        document.getElementById("sign_up_form").submit();
    }
}