from django.db import models

# Create your models here.
class clients(models.Model):
    first_name=models.CharField(maxfield=50, db_colomn='First_name')
    last_name=models.CharField(maxfield=50, db_colomn='Last_name')
    patronymic=models.CharField(maxfield=50, db_colomn='Patronymic')
    phone_number=models.CharField(maxfield=13, db_colomn='Phone_number')
    passport_number_and_series=models.CharField(max_lenght=8, db_colomn='Passport_number_and_series')

    class Meta:
        managed = False
        db_table = 'clients'

class employees(models.Model):
    first_name=models.CharField(maxfield=50, db_colomn='First_name')
    last_name=models.CharField(maxfield=50, db_colomn='Last_name')
    patronymic=models.CharField(maxfield=50, db_colomn='Patronymic')
    phone_number=models.CharField(maxfield=13, db_colomn='Phone_number')
    salary=models.IntegerField(db_colomn='Salary')
    award=models.IntegerField(db_colomn='Award')

    class Meta:
        managed = False
        db_table = 'employees'

class tours(models.Model):
    termination_date=models.DateField(db_colomn='Termination_date')
    ammount_of_tour_days=models.IntegerField(db_colomn='Ammount_of_tour_days')
    description=models.CharField(maxfield=250, db_colomn='Description')
    price=models.IntegerField(db_colomn='Price')
    amount_of_travelers=models.IntegerField(db_colomn='Amount_of_travelers')

    class Meta:
        managed = False
        db_table = 'tours'

class registration(models.Model):
    client_id=models.ForeignKey('clients',models.DO_NOTHING, blank=True, null=True, db_colomn='Client_id')
    employee_id=models.ForeignKey('employees',models.DO_NOTHING, blank=True, null=True, db_colomn='Employee_id')
    tour_id=models.ForeignKey('tours',models.DO_NOTHING, blank=True, null=True, db_colomn='Tour_id')
    registration_date=models.DateField(db_colomn='Registration_date')

    class Meta:
        managed = False
        db_table = 'registration'

class city(models.Model):
    city_name=models.CharField(maxfield=50, db_colomn='City_name')

    class Meta:
        managed = False
        db_table = 'city'

class country(models.Model):
    country_name=models.CharField(maxfield=50, db_colomn='Country_name')

    class Meta:
        managed = False
        db_table = 'city'

class TCC(models.Model):
    city_id=models.ForeignKey('city',models.DO_NOTHING, blank=True, null=True, db_colomn='City_id')
    country_id=models.ForeignKey('country',models.DO_NOTHING, blank=True, null=True, db_colomn='Country_id')
    tour_id=models.ForeignKey('tours',models.DO_NOTHING, blank=True, null=True, db_colomn='Tour_id')

    class Meta:
        managed = False
        db_table = 'TCC'

class place_of_residence(models.Model):
    name_of_place_of_residence=models.CharField(maxfield=50, db_colomn='Name_of_place_of_residence')
    class_of_place_of_residence=models.CharField(maxfield=50, db_colomn='Class_of_place_of_residence')
    type_of_place_of_residence=models.CharField(maxfield=50, db_colomn='Type_of_place_of_residence')

    class Meta:
        managed = False
        db_table = 'place_of_residence'

class transport(models.Model):
    class_of_transport=models.CharField(maxfield=50, db_colomn='Class_of_transport')
    type_of_transport=models.CharField(maxfield=50, db_colomn='Type_of_transport')

    class Meta:
        managed = False
        db_table = 'transport'

class insurance_agency(models.Model):
    name_of_insurance_agency=models.CharField(maxfield=50, db_colomn='Name_of_insurance_agency')
    price_of_insurance=models.IntegerField(db_colomn='Price_of_insurance')
    payout_amount=models.IntegerField(db_colomn='Payout_amount')
    class Meta:
        managed = False
        db_table = 'insurance_agency'

class residence(models.Model):
    client_id=models.ForeignKey('clients',models.DO_NOTHING, blank=True, null=True, db_colomn='Client_id')
    TCC_id=models.ForeignKey('TCC',models.DO_NOTHING, blank=True, null=True, db_colomn='TCC_id')
    place_of_residence_id=models.ForeignKey('place_of_residence',models.DO_NOTHING, blank=True, null=True, db_colomn='Place_of_residence_id')

    class Meta:
        managed = False
        db_table = 'residence'

class passage(models.Model):
    client_id=models.ForeignKey('clients',models.DO_NOTHING, blank=True, null=True, db_colomn='Client_id')
    TCC_id=models.ForeignKey('TCC',models.DO_NOTHING, blank=True, null=True, db_colomn='TCC_id')
    transport_id=models.ForeignKey('transport',models.DO_NOTHING, blank=True, null=True, db_colomn='Transport')

    class Meta:
        managed = False
        db_table = 'passage'

class insurance(models.Model):
    client_id=models.ForeignKey('clients',models.DO_NOTHING, blank=True, null=True, db_colomn='Client_id')
    tour_id=models.ForeignKey('Tour',models.DO_NOTHING, blank=True, null=True, db_colomn='Tour_id')
    insurance_agency_id=models.ForeignKey('insurance_agency',models.DO_NOTHING, blank=True, null=True, db_colomn='Insurance_agency')

    class Meta:
        managed = False
        db_table = 'passage'

class employee_reviews(models.Model):
    employee_id=models.ForeignKey('employee',models.DO_NOTHING, blank=True, null=True, db_colomn='employee_id')
    client_id=models.ForeignKey('clients',models.DO_NOTHING, blank=True, null=True, db_colomn='Client_id')
    text=models.CharField(maxfield=250, db_colomn='text')
    mark=models.IntegerField(db_colomn='mark')

    class Meta:
        managed = False
        db_table = 'employee_reviews'

class tour_reviews(models.Model):
    tour_id=models.ForeignKey('Tour',models.DO_NOTHING, blank=True, null=True, db_colomn='Tour_id')
    client_id=models.ForeignKey('clients',models.DO_NOTHING, blank=True, null=True, db_colomn='Client_id')
    text=models.CharField(maxfield=250, db_colomn='text')
    mark=models.IntegerField(db_colomn='mark')

    class Meta:
        managed = False
        db_table = 'tour_reviews'

class report(models.Model):
    tour_id=models.ForeignKey('Tour',models.DO_NOTHING, blank=True, null=True, db_colomn='Tour_id')
    employee_id=models.ForeignKey('employee',models.DO_NOTHING, blank=True, null=True, db_colomn='employee_id')
    text=models.CharField(maxfield=250, db_colomn='text')

    class Meta:
        managed = False
        db_table = 'report'

class registration_request(models.Model):
    tour_id=models.ForeignKey('Tour',models.DO_NOTHING, blank=True, null=True, db_colomn='Tour_id')
    client_id=models.ForeignKey('clients',models.DO_NOTHING, blank=True, null=True, db_colomn='Client_id')

    class Meta:
        managed = False
        db_table = 'registration_request'

class call_request(models.Model):
    phone_number=models.CharField(maxfield=13, db_colomn='Phone_number')
    client_id=models.ForeignKey('clients',models.DO_NOTHING, blank=True, null=True, db_colomn='Client_id')

    class Meta:
        managed = False
        db_table = 'call_request'