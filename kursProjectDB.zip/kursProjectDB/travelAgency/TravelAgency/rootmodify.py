from django.http import HttpResponse,JsonResponse

from django.contrib.auth import logout, login, authenticate
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.models import User
from django.contrib.messages import error as ms_error

from django.views.generic.list import ListView
import os

import datetime




def ChangeDbUser(Request):
    if request.user.groups.filter(name="admin").exists():
        return
    else:
        if request.user.groups.filter(name="realtor").exists():
            return
        else:
            return

            
def DefaultUser():
    return

