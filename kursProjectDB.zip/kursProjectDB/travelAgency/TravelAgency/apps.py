from django.apps import AppConfig


class TravelagencyConfig(AppConfig):
    name = 'TravelAgency'
