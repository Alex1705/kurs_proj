from django.db import models

# Create your models here.


class customers(models.Model):#psql table - "customers"
    telephone_number = models.CharField(max_length=50)
    e_mail=models.CharField(max_length=50)
    Name=models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'customers'

class realtors(models.Model):#psql table - "realtors"
    telephone_number = models.CharField(max_length=50, db_column='telephone_number')
    e_mail=models.CharField(max_length=50, db_column='e_mail')
    Name=models.CharField(max_length=50, db_column='name')

    class Meta:
        managed = False
        db_table = 'realtors'

class houses(models.Model):#psql table - "houses"
    yard_area=models.IntegerField(db_column='yard_area')
    number_of_floors= models.IntegerField(db_column='number_of_floors')

    class Meta:
        managed = False
        db_table = 'houses'

class rooms(models.Model):#psql table - "rooms"
    balcony=models.BooleanField(db_column='balcony')
    floor= models.IntegerField(db_column='floor')

    class Meta:
        managed = False
        db_table = 'rooms'

class offices(models.Model):#psql table - "offices"
    kitchen=models.BooleanField(db_column='kitchen')
    bathroom=models.BooleanField(db_column='bathroom')
    floor= models.IntegerField(db_column='floor')

    class Meta:
        managed = False
        db_table = 'offices'

class immovables(models.Model):#psql table - "immovables"
    owner_id=models.ForeignKey('customers', models.DO_NOTHING, blank=True, null=True,db_column='owner_id')
    realtor_id=models.ForeignKey('realtors', models.DO_NOTHING, blank=True, null=True, db_column='realtor_id')
    yard_area=models.IntegerField(db_column='yard_area')
    number_of_rooms=models.IntegerField(db_column='number_of_rooms')
    for_sale=models.BooleanField(db_column='for_sale')
    rent=models.BooleanField(db_column='rent')
    s_price=models.IntegerField(db_column='s_price')
    r_price=models.IntegerField(db_column='r_price')
    type_id=models.IntegerField(db_column='type_id')
    type=models.CharField(max_length=50,db_column='type')

    class Meta:
        managed = False
        db_table = 'immovables'

class deals(models.Model):#psql table - "deals"
    immovables_id=models.ForeignKey('immovables', models.DO_NOTHING, blank=True, null=True,db_column='immovables_id')
    owner_id=models.ForeignKey('customers', models.DO_NOTHING, blank=True, null=True,db_column='owner_id')
    realtor_id=models.ForeignKey('realtors', models.DO_NOTHING, blank=True, null=True, db_column='realtor_id')
    customer_id=models.IntegerField( db_column='customer_id')
    price=models.IntegerField(db_column='price')
    day=models.IntegerField(db_column='day')
    month=models.IntegerField(db_column='month')
    year=models.IntegerField(db_column='year')


    class Meta:
        managed = False
        db_table = 'deals'
