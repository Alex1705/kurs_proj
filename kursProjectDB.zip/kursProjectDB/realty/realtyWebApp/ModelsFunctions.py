from django.db import connection
from django.shortcuts import get_object_or_404
from django.http import HttpResponse
import datetime
from django.utils.safestring import mark_safe

from .models import customers, realtors, immovables, offices, rooms, houses, deals

def select_immovables():
    str_query ="select id, realtor_id, area, number_of_rooms, s_price, r_price, type, type_id from immovables order by id desc limit 10 "
    cursor = connection.cursor()
    cursor.execute(str_query)
    query_res = cursor.fetchall()
    query_res=list(query_res)
    for row in query_res:
        cursor.execute("select Name from realtors where id = "+str(list(row))[1])
        localQres=cursor.fetchall()[0]
        if not  localQres[0] is None:
            row[1]=localQres[0]
    return 