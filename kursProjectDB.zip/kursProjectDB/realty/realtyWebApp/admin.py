from django.contrib import admin

# Register your models here.
from .models import customers, realtors, immovables, houses, rooms, offices, deals
# Register your models here.

admin.site.register (customers)
admin.site.register (realtors)
admin.site.register (houses)
admin.site.register (rooms)
admin.site.register (immovables)
admin.site.register (offices)
admin.site.register (deals)
