from django.http import HttpResponse,JsonResponse

from django.shortcuts import render, redirect

from django.contrib.auth import logout, login, authenticate
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.models import User
from django.contrib.messages import error as ms_error

from django.views.generic.list import ListView

import datetime
from .models import customers, realtors, immovables, houses, rooms, offices, deals
from . import rootmodify as rm
from . import ModelsFunctions as ModFun

# Create your views here.

def main_page(request, *args, **kwargs):
    context={}
    ModFun.select_immovables()
    return render(request,"main.html",context)

def register_user_view(request):#отрисовка страницы регистрации, регистрация
    if request.method == "POST":     #если пост, значит данные о пользователе введены, создаем и выполняем вход
        username = request.POST['username']
        mail = request.POST['email']
        password = request.POST['password']

        if mail != "":
            user = User.objects.create_user(username, email = mail, password = password)

        else:
            user = User.objects.create_user(username, password = password)

        user.save()
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            
        else:
            ms_error(request, ('Your credentials are wrong. Sorry.'))
            # = request.REQUEST.get(REDIRECT_FIELD_NAME, reverse('frontend:index'))

        return redirect('main')

    else:                       #иначе отрисовываем форму создания
        return render (request, 'sign_up.html',{})

def sign_in_view(request):#отрисовка страницы входа
    #request.path = ''
    return render(request, 'sign_in.html')

def loginer_view(request):#обработка входа
    """
    Вызывает соответствующее представление Django, анализирует результат.
    В случае ошибки генерирует сообщение и возвращает пользователя на прежнюю страницу.
    """
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
    else:
        ms_error(request, ('Your credentials are wrong. Sorry.'))
        # = request.REQUEST.get(REDIRECT_FIELD_NAME, reverse('frontend:index'))
    if not request.user.is_authenticated:
        context = {
            'message': "Пользователь с такими логином и паролем не зарегистрирован"
        }
        return render(request, 'sign_in.html', context)
    if request.user.groups.filter(name='admin').exists():
        
        return redirect('admin_page')
    return redirect('main')

def logout_view(request):#обработка выхода
    print ("User is trying to logout")
    logout(request)
    return redirect('main')


def admin_page_view(request):#админ панель 
    if not request.user.groups.filter(name='admin').exists():
        return redirect('main')
    return  render(request, 'admin_page.html')

