from django.apps import AppConfig


class RealtywebappConfig(AppConfig):
    name = 'realtyWebApp'
